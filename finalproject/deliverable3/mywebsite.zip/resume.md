![picture](avatar.png)<br>

# Christian Torres-Quinteros
## Contact Information:
Address: Paterson, NJ
Email: cltorres-quinteros@students.pccc.edu

## Information
Information Technology (Technical Support) major seeking and ready for opportunities to apply technical knowledge and skills. Dedicated IT major with a strong foundation in technical support and a passion for resolving complex issues. Wants to be armed with hands-on experience in troubleshooting hardware, software, and network problems with the help of an internship. 

## Education
Passaic County Community College
Major: Information Technology (Technical Support)

## Work Experience
While I have not had a job related to IT just yet, I have worked with my father in his construction (Masonry) company. I work with him when I am not in school and I provide the invoices that my father hands to his customers.

## Internship
Since I have not yet gotten any work experience related to my major, I would love to get into an internship. This would be a great opportunity to gain experience and great preparation for getting into the actual workforce. Getting hands-on experience and enhancing my skills before graduation is a must.

## Skills
* Programming language specifically Python
* Database Management
* Software and hardware maintenance
* Adaptability
* Problem-Solving

## Courses that have increased my technological skills
* CIS 290 Database Fundamentals
* CIS 108 Programming Fundamentals
* CIS 180 Networking Essentials
* CIS 125 Microcomputer Software
* CIS 106 Linux Fundamentals
